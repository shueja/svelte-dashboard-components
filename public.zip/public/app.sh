
start msedge.exe --allow-file-access-from-files --app="$PWD/index.html" --user-data-dir="%Temp%/frc-dashboard-profile"